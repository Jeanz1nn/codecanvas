from .color import back, fore
from .style import reset, decoration